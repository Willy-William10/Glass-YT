# Glass YT v2.5

Glass YT v2.5 is a Manifest V3 extension for Brave and Chromium browsers. It gives the complete YouTube surface a visual-only liquid-glass redesign while retaining YouTube's native controls, playback, navigation, account behavior, and accessibility semantics.

## Install in Brave

1. Open `brave://extensions`.
2. Turn on **Developer mode** in the upper-right corner.
3. Select **Load unpacked**.
4. Choose this `glass-yt` folder.
5. Open `https://www.youtube.com/`, select the Glass YT extension icon, then turn on **Glass Mode**.
6. Use **Open advanced settings** in the popup for the full Appearance, Typography, Animations, YouTube, Performance, and Accessibility panels.

The setting is stored with `chrome.storage.sync`, so it applies automatically to later YouTube tabs and browser sessions. Use the same popup switch to turn the effect off instantly; no page reload is needed. Advanced settings include glass strength, background blur, theme color, friendly performance controls, a default-off animated reflection, category glass pills, and an optional lightweight Ad Blocker.

## Design and compatibility notes

- CSS is entirely gated behind `html[data-glass-yt="enabled"]`. Turning Glass Mode off removes that attribute and restores standard YouTube styling.
- The stylesheet adapts automatically to YouTube's `dark` theme attribute and includes a separate light-glass palette.
- It uses no external libraries, background network calls, tracking, DOM replacement, video changes, or account/data collection.
- The optional Ad Blocker hides known YouTube ad containers and only watches the active player for YouTube's own skip button. It does not poll or scan the full page continuously, and YouTube may still serve ads it cannot control.
- SPA navigation remains covered because the stylesheet applies to newly rendered YouTube views, and the content script maintains visual state on YouTube navigation events.
- The extension declares only `storage`, `activeTab`, and the YouTube host permission required to inject its local visual stylesheet.

## Structure

```
glass-yt/
├── manifest.json       # Manifest V3 configuration and minimal permissions
├── config.js           # Shared theme presets, settings schema, and font catalog
├── content.js          # Persistent visual state and CSS-variable controller
├── content.css         # Gated liquid-glass redesign
├── popup.html          # Compact extension control panel
├── popup.css           # Popup glass design
├── popup.js            # Popup state and active-tab messaging
├── options.html        # Full settings page
├── options.css         # Settings page glass design
├── options.js          # Live settings controls and persistence
├── CHANGELOG.md        # Version/checkpoint log
└── icons/              # PNG extension icons plus editable SVG source
```

## Quick manual check

With Glass Mode enabled, visit the YouTube home feed, search results, a watch page, a channel, a playlist, and Shorts. Open the account/menu panels and video settings, then switch YouTube between light and dark themes. Toggle Glass Mode off to confirm the normal YouTube presentation is restored.
